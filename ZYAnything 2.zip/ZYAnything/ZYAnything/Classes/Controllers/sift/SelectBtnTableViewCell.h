//
//  SelectBtnTableViewCell.h
//  ZYAnything
//
//  Created by ZhangZiyao on 16/1/7.
//  Copyright © 2016年 soez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectBtnTableViewCell : UITableViewCell

//- void(^)(int,int,int,int) callBack;



@end
