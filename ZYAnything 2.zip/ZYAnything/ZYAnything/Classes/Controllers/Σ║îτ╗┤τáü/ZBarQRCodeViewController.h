//
//  ZBarQRCodeViewController.h
//  ZYAnything
//
//  Created by ZhangZiyao on 15/11/17.
//  Copyright © 2015年 soez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"

@interface ZBarQRCodeViewController : UIViewController<ZBarReaderDelegate>


@end
