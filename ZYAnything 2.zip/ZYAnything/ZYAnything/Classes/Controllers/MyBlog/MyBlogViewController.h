//
//  MyBlogViewController.h
//  ZYAnything
//
//  Created by ZhangZiyao on 15/12/15.
//  Copyright © 2015年 soez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBlogViewController : UIViewController

@end
