//
//  VisitPhotoViewController.h
//  ZYAnything
//
//  Created by ZhangZiyao on 15/11/15.
//  Copyright © 2015年 soez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VisitPhotoViewController : UIViewController

@end
